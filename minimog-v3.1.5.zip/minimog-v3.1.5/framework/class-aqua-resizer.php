<?php

/**
 * Title         : Aqua Resizer
 * Description   : Resizes WordPress images on the fly
 * Version       : 1.2.2
 * Author        : Syamil MJ
 * Author URI    : https://aquagraphite.com
 * License       : WTFPL - https://sam.zoy.org/wtfpl/
 * Documentation : https://github.com/sy4mil/Aqua-Resizer/
 *
 * @param string $url     - (required) must be uploaded using wp media uploader
 * @param int    $width   - (required)
 * @param int    $height  - (optional)
 * @param bool   $crop    - (optional) default to soft crop
 * @param bool   $single  - (optional) returns an array if false
 * @param bool   $upscale - (optional) resizes smaller images
 *
 * @uses  wp_upload_dir()
 * @uses  image_resize_dimensions()
 * @uses  wp_get_image_editor()
 *
 * @return str|array
 */

if ( ! class_exists( 'Aq_Resize' ) ) {
	class Aq_Exception extends Exception {

	}

	class Aq_Resize {

		/**
		 * The singleton instance
		 */
		static private $instance = null;

		/**
		 * Should an Aq_Exception be thrown on error?
		 * If false (default), then the error will just be logged.
		 */
		public $throwOnError = false;

		/**
		 * No initialization allowed
		 */
		private function __construct() {
		}

		/**
		 * No cloning allowed
		 */
		private function __clone() {
		}

		/**
		 * For your custom default usage you may want to initialize an Aq_Resize object by yourself and then have own defaults
		 */
		static public function getInstance() {
			if ( self::$instance == null ) {
				self::$instance = new self;
			}

			return self::$instance;
		}

		/**
		 * Run, forest.
		 */
		public function process( $url, $width = null, $height = null, $crop = null, $single = true, $upscale = false ) {
			try {
				// Validate inputs.
				if ( ! $url ) {
					throw new Aq_Exception( '$url parameter is required' );
				}
				if ( ! $width ) {
					throw new Aq_Exception( '$width parameter is required' );
				}

				// Caipt'n, ready to hook.
				if ( true === $upscale ) {
					add_filter( 'image_resize_dimensions', array( $this, 'aq_upscale' ), 10, 6 );
				}

				// Define upload path & dir.
				$upload_info = wp_upload_dir();
				$upload_dir  = $upload_info['basedir'];
				$upload_url  = $upload_info['baseurl'];

				$http_prefix     = "http://";
				$https_prefix    = "https://";
				$relative_prefix = "//"; // The protocol-relative URL

				/* if the $url scheme differs from $upload_url scheme, make them match
				   if the schemes differe, images don't show up. */
				if ( ! strncmp( $url, $https_prefix, strlen( $https_prefix ) ) ) { //if url begins with https:// make $upload_url begin with https:// as well
					$upload_url = str_replace( $http_prefix, $https_prefix, $upload_url );
				} elseif ( ! strncmp( $url, $http_prefix, strlen( $http_prefix ) ) ) { //if url begins with http:// make $upload_url begin with http:// as well
					$upload_url = str_replace( $https_prefix, $http_prefix, $upload_url );
				} elseif ( ! strncmp( $url, $relative_prefix, strlen( $relative_prefix ) ) ) { //if url begins with // make $upload_url begin with // as well
					$upload_url = str_replace( array(
						0 => "$http_prefix",
						1 => "$https_prefix",
					), $relative_prefix, $upload_url );
				}


				// Check if $img_url is local.
				if ( false === strpos( $url, $upload_url ) ) {
					throw new Aq_Exception( 'Image must be local: ' . $url );
				}

				// Define path of image.
				$rel_path = str_replace( $upload_url, '', $url );
				$img_path = $upload_dir . $rel_path;

				// Check if img path exists, and is an image indeed.
				if ( ! file_exists( $img_path ) or ! getimagesize( $img_path ) ) {
					throw new Aq_Exception( 'Image file does not exist (or is not an image): ' . $img_path );
				}

				// Get image info.
				$info = pathinfo( $img_path );
				$ext  = $info['extension'];
				list( $orig_w, $orig_h ) = getimagesize( $img_path );

				// Get image size after cropping.
				$dims    = image_resize_dimensions( $orig_w, $orig_h, $width, $height, $crop );
				$img_url = '';

				$suffix = $dst_rel_path = '';
				// Return the original image only if it exactly fits the needed measures.
				if ( ! $dims || ( ( ( null === $height && $orig_w == $width ) xor ( null === $width && $orig_h == $height ) ) xor ( $height == $orig_h && $width == $orig_w ) ) ) {
					$img_url = $url;
					$dst_w   = $orig_w;
					$dst_h   = $orig_h;
				} else {
					$dst_w = isset( $dims[4] ) ? $dims[4] : $orig_w;
					$dst_h = isset( $dims[5] ) ? $dims[5] : $orig_h;
					// Use this to check if cropped image already exists, so we can return that instead.
					$suffix       = "{$dst_w}x{$dst_h}";
					$dst_rel_path = str_replace( '.' . $ext, '', $rel_path );
					$destfilename = "{$upload_dir}{$dst_rel_path}-{$suffix}.{$ext}";

					if ( ! $dims || ( true == $crop && false == $upscale && ( $dst_w < $width || $dst_h < $height ) ) ) {
						// Can't resize, so return false saying that the action to do could not be processed as planned.
						throw new Aq_Exception( 'Unable to resize image because image_resize_dimensions() failed' );
					} // Else check if cache exists.
					elseif ( file_exists( $destfilename ) && getimagesize( $destfilename ) ) {
						$img_url = "{$upload_url}{$dst_rel_path}-{$suffix}.{$ext}";
					} // Else, we resize the image and return the new resized image url.
					else {

						$editor = wp_get_image_editor( $img_path );

						if ( is_wp_error( $editor ) || is_wp_error( $editor->resize( $width, $height, $crop ) ) ) {
							throw new Aq_Exception( 'Unable to get WP_Image_Editor: (is GD or ImageMagick installed?)' );
						}

						$resized_file = $editor->save();

						if ( ! is_wp_error( $resized_file ) ) {
							$resized_rel_path = str_replace( $upload_dir, '', $resized_file['path'] );
							$img_url          = $upload_url . $resized_rel_path;

							// Add the resized dimensions to original image metadata (so we can delete our resized images when the original image is delete from the Media Library).
							global $wpdb;
							$query          = $wpdb->prepare( "SELECT * FROM $wpdb->posts WHERE guid='%s'", $url );
							$get_attachment = $wpdb->get_results( $query );
							if ( ! $get_attachment ) {
								return array( 0 => $url, 1 => $width, 2 => $height );
							}

							$metadata = wp_get_attachment_metadata( $get_attachment[0]->ID );
							if ( isset( $metadata['image_meta'] ) ) {
								$metadata['image_meta']['resized_images'][] = $dst_w . 'x' . $dst_h;
								wp_update_attachment_metadata( $get_attachment[0]->ID, $metadata );
							}
						} else {
							//throw new Aq_Exception('Unable to save resized image file: ' . $editor->get_error_message());
						}

					}
				}

				// Okay, leave the ship.
				if ( true === $upscale ) {
					remove_filter( 'image_resize_dimensions', array( $this, 'aq_upscale' ) );
				}

				// Return the output.
				if ( $single ) {
					// str return.
					$image = $img_url;
				} else {
					// array return.
					$image = array(
						0 => $img_url,
						1 => $dst_w,
						2 => $dst_h,
					);
				}

				// RETINA Support
				if ( Minimog::setting( 'retina_display_enable' ) ) {
					$retina_w = $dst_w * 2;
					$retina_h = $dst_h * 2;

					// Get image size after cropping.
					$dims_x2  = image_resize_dimensions( $orig_w, $orig_h, $retina_w, $retina_h, $crop );
					$dst_x2_w = isset( $dims_x2[4] ) ? $dims_x2[4] : false;
					$dst_x2_h = isset( $dims_x2[5] ) ? $dims_x2[5] : false;

					// If possible lets make the @2x image
					if ( $dst_x2_h ) {

						//@2x image url
						$destfilename = "{$upload_dir}{$dst_rel_path}-{$suffix}@2x.{$ext}";

						//check if retina image exists
						if ( file_exists( $destfilename ) && getimagesize( $destfilename ) ) {
							// already exists, do nothing
						} else {
							// doesnt exist, lets create it
							$editor = wp_get_image_editor( $img_path );
							if ( ! is_wp_error( $editor ) ) {
								$editor->resize( $retina_w, $retina_h, $crop );
								$editor->set_quality( 100 );
								$filename = $editor->generate_filename( $dst_w . 'x' . $dst_h . '@2x' );
								$editor   = $editor->save( $filename );
								// Add the resized dimensions to original image metadata (so we can delete our resized retina images when the original image is delete from the Media Library)
								global $wpdb;
								$query          = $wpdb->prepare( "SELECT * FROM $wpdb->posts WHERE guid='%s'", $url );
								$get_attachment = $wpdb->get_results( $query );
								if ( ! $get_attachment ) {
									return array( 0 => $url, 1 => $width, 2 => $height );
								}
								$metadata = wp_get_attachment_metadata( $get_attachment[0]->ID );
								if ( isset( $metadata['image_meta'] ) ) {
									$metadata['image_meta']['resized_images'][] = $dst_w . 'x' . $dst_h . '@2x';
									wp_update_attachment_metadata( $get_attachment[0]->ID, $metadata );
								}
							}
						}

					}
				}

				return $image;
			} catch ( Aq_Exception $ex ) {
				//error_log( 'Aq_Resize.process() error: ' . $ex->getMessage() );

				if ( $this->throwOnError ) {
					// Bubble up exception.
					throw $ex;
				} else {
					// Return false, so that this patch is backwards-compatible.
					return false;
				}
			}
		}

		/**
		 * Callback to overwrite WP computing of thumbnail measures
		 */
		function aq_upscale( $default, $orig_w, $orig_h, $dest_w, $dest_h, $crop ) {
			if ( ! $crop ) {
				return null;
			} // Let the wordpress default function handle this.

			// Here is the point we allow to use larger image size than the original one.
			$aspect_ratio = $orig_w / $orig_h;
			$new_w        = $dest_w;
			$new_h        = $dest_h;

			if ( ! $new_w ) {
				$new_w = intval( $new_h * $aspect_ratio );
			}

			if ( ! $new_h ) {
				$new_h = intval( $new_w / $aspect_ratio );
			}

			$size_ratio = max( $new_w / $orig_w, $new_h / $orig_h );

			$crop_w = round( $new_w / $size_ratio );
			$crop_h = round( $new_h / $size_ratio );

			$s_x = floor( ( $orig_w - $crop_w ) / 2 );
			$s_y = floor( ( $orig_h - $crop_h ) / 2 );

			return array( 0, 0, (int) $s_x, (int) $s_y, (int) $new_w, (int) $new_h, (int) $crop_w, (int) $crop_h );
		}
	}
}


if ( ! function_exists( 'aq_resize' ) ) {

	/**
	 * This is just a tiny wrapper function for the class above so that there is no
	 * need to change any code in your own WP themes. Usage is still the same :)
	 */
	function aq_resize( $url, $width = null, $height = null, $crop = null, $single = true, $upscale = false ) {
		$aq_resize = Aq_Resize::getInstance();

		return $aq_resize->process( $url, $width, $height, $crop, $single, $upscale );
	}
}


/**
 *  Deletes the resized images when the original image is deleted from the WordPress Media Library.
 */
add_action( 'delete_attachment', 'aq_delete_resized_images' );

if ( ! function_exists( 'aq_delete_resized_images' ) ) {
	function aq_delete_resized_images( $post_id ) {
		// Get attachment image metadata.
		$metadata = wp_get_attachment_metadata( $post_id );
		if ( ! $metadata ) {
			return;
		}
		// Do some bailing if we cannot continue.
		if ( ! isset( $metadata['file'] ) || ! isset( $metadata['image_meta']['resized_images'] ) ) {
			return;
		}
		$pathinfo       = pathinfo( $metadata['file'] );
		$resized_images = $metadata['image_meta']['resized_images'];
		// Get Wordpress uploads directory (and bail if it doesn't exist)
		$wp_upload_dir = wp_upload_dir();
		$upload_dir    = $wp_upload_dir['basedir'];
		if ( ! is_dir( $upload_dir ) ) {
			return;
		}
		// Delete the resized images
		foreach ( $resized_images as $dims ) {
			// Get the resized images filename
			$file        = $upload_dir . DIRECTORY_SEPARATOR . $pathinfo['dirname'] . DIRECTORY_SEPARATOR . $pathinfo['filename'] . '-' . $dims . '.' . $pathinfo['extension'];
			$file_retina = $upload_dir . DIRECTORY_SEPARATOR . $pathinfo['dirname'] . DIRECTORY_SEPARATOR . $pathinfo['filename'] . '-' . $dims . '@2x.' . $pathinfo['extension'];
			// Delete the resized image
			@unlink( $file );
			@unlink( $file_retina );
		}
	}
}
